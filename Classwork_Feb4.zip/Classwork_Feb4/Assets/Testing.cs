﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Testing : MonoBehaviour
{
    string[] localArray = new string[] { "cool", "code", "math" };
    string[] secondArray;

    List<string> greetings = new List<string>();
    Queue<int> myQ = new Queue<int>();

    List<string> myString = new List<string>() {"Hello" };


    void Start()
    {
        /* greetings.Add("Hello");
        greetings.Add("What's Up");
        greetings.Add("Salutations");
        Debug.Log(greetings[0]);

        Debug.Log(greetings[Random.Range(0, greetings.Count)]);

        secondArray = localArray;
        localArray[0] = "something different";
        Debug.Log(secondArray[0]);

        for(int i =0; i < localArray.Length; i++)
        {
            Debug.Log(localArray[0]);
            Debug.Log(localArray[1]);
            Debug.Log(localArray[2]);
        } */

        Debug.Log(HelloListMaker(5)[2]);
    }
    
    void Update()
    {
      
    }

    List<string> HelloListMaker (int qty)
    {
        List<string> toreturn = new List<string>();
        for (int i = 0; i < qty; i++)
        {
            toreturn.Add("Hello");
        }
        return toreturn;
    }
    
    int LastintDoubler(int[] array)
    {
        return array[array.Length - 1]*2s;
    }
}
