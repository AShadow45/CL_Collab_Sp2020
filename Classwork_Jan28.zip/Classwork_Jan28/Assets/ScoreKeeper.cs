﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScoreKeeper : MonoBehaviour
{
    public int score;

    void Start()
    {
        
    }
    
    void Update()
    {
        
    }

    /// <summary>
    /// This is the amount the score will increase
    /// </summary>
    /// <param name="increaseamt"></param>


    public void IncreaseScore(int increaseamt)
    {
        if(increaseamt > 0) {
            Debug.Log(“Increasing score”);
            score += increaseamt;
            return true;
        }

        else {
            return false;
        }
    }

    int Double(int todouble)
    {
        return todouble *2;
    }

    int OneorZero(string thingtoreturn)
    {
        if(thingtoreturn == “One”){
            return 1;
        }

        else{
            return 0;
        }
    }

}
