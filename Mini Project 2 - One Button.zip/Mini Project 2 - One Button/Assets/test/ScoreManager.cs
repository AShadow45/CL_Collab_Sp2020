﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScoreManager : MonoBehaviour
{
    public int score = 0;
    // Start is called before the first frame update
    void Start()
    {
        //IncreaseScore();
        int test = 7;
        int testdoubled = Double(test);
        Debug.Log(Double(test));
        Debug.Log(testdoubled);

        test = OneOrZero("One");
    }

    // Update is called once per frame
    void Update()
    {
        //if (Input.GetKeyDown(KeyCode.Space))
        //{
            //IncreaseScore();
        //}
    }

    /// <summary>
    /// This increases the score by the amount passed 
    /// </summary>
    

    public bool IncreaseScore(int increaseamt)
    {
        if (increaseamt > 0) {
            Debug.Log("Increasing score");
            score += increaseamt;
            return true;
        } else { return false; }
    }

    int Double(int todouble)
    {
        return todouble * 2;
    }

    int OneOrZero(string thingtoreturn)
    {
        if (thingtoreturn == "One")
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }

    public int CheatMode(string cheatCode)
    {
        if (cheatCode == "Up, Down, Left")
        {
            Debug.Log("Cheat Activated");
            return 1;
        }
        else
        {
            return 0;
        }
    }


    /*
    this commented a section of code out
    */

    
}
