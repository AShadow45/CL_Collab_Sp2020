﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[SelectionBase]
[AddComponentMenu("My Scripts/ Game Manager")]
public class GameManager : MonoBehaviour
{
    [ContextMenuItem("Get a random time", "Pick random time length")]
    [Header("Important game variables")] //for organization
    [Range(0, 100f)] public float gameLength; //the length of game in seconds

    [Header("References other script")]
    public ScoreManager scoremanager;
    //some other example for organization functions
    [HideInInspector] public float animaDuration = 10f; //hide what is public
    [SerializeField] private float playerHealth; //show what is private

    //[InspectorName("PlayerName")]public string plname;
    [Tooltip("this is the player's name")] public string plname; //helped to id what the function's purpose

    // Start is called before the first frame update
    void Start()
    {
        scoremanager.IncreaseScore(5);
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    //[ContextMenuItem("Get a random time", "Pick random time length")]
    void PickRandomGameLength()
    {
        gameLength = Random.Range(0f, 100f);
    }
}
