﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Buttons : MonoBehaviour
{
    public int sceneNum;

    public void RetryGame()
    {
        SceneManager.LoadScene(sceneNum);
    }

    public void StartGame()
    {

        if (Input.GetKey(KeyCode.Space))
        {
            SceneManager.LoadScene(sceneNum);
        }
    }

    public void ClicktoStart()
    {
        SceneManager.LoadScene(sceneNum);
    }
}
