﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerMovement : MonoBehaviour
{
    //..............................................MOVEMENT
    public float moveSpeed;
    Rigidbody2D rb;

    //..............................................ANIMATION
    Animator anim;
    //..............................................otherStuffs
    public int sceneNum;

    void Awake()
    {
        anim = gameObject.GetComponent<Animator>();
    }
   
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }
    
    void Update()
    {
        //........................................MOVEMENT
        rb.velocity = new Vector2(moveSpeed, rb.velocity.y);

        //........................................ANIMATION
        anim.SetBool("doRun", true);
    }

    void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.tag == "spike")
        {
            SceneManager.LoadScene(sceneNum);
        }
    }
    /*
    public Vector3 GetPosition()
    {
        return transform.position;
    }
    */
}
