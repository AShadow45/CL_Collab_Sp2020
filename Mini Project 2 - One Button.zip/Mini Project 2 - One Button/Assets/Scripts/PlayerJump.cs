﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;


public class PlayerJump : MonoBehaviour
{
    //..............................................JUMP
    [Range(1, 10)]
    public float jumpVelocity;
    public bool canJump = true;

    //..............................................ANIMATION
    Animator anim;

    //...............................................Sound Effect
    public AudioSource JumpSound;
    
    void Awake()
    {
        anim = gameObject.GetComponent<Animator>();
    }
    
    void OnCollisionEnter2D (Collision2D other)
    {
        if(other.gameObject.tag == "Ground")
        {
            canJump = true;

            //........................................ANIMATION
            anim.SetBool("doJump", false);
            anim.SetBool("doRun", true);
        }
    }
    void Update()
    {
        if (Input.GetButtonDown("Jump") && canJump == true)
        {
            GetComponent<Rigidbody2D>().velocity = Vector2.up * jumpVelocity;
            canJump = false;

            //........................................ANIMATION
            anim.SetBool("doJump", true);
            anim.SetBool("doRun", false);

            //........................................SOUND
            JumpSound.Play();
        }
    }
}
