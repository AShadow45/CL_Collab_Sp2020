﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerHealth : MonoBehaviour
{
    //Health bar reference
    public Image healthBar;

    //player health
    public float startHealth = 100; //starting health for the player
    private float health; //current health of the player
    public float damagePerSec = 10;
    public float recoverAmount = 2;

    //sound effect

    public AudioSource EatSound;

    //other stuffs
    public int sceneNum;

    void Start()
    {
        health = startHealth;
    }

    
    void Update()
    {
        health -= Time.deltaTime * damagePerSec;
        healthBar.fillAmount = health / startHealth;

        if (health <= 0)
        {
            Die();
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.tag == "food")
        {
            health += recoverAmount;
            healthBar.fillAmount = health / startHealth;
            Destroy(other.gameObject);
            EatSound.Play();
        }
    }


    void Die()
    {
        SceneManager.LoadScene(sceneNum);
    }
}
