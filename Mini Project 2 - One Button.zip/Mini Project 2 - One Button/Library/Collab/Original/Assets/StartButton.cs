﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class StartButton : MonoBehaviour
{
    // When SPACEBAR is pressed the game will start
   public void StartGame() {

        if (Input.GetKey(KeyCode.Space))
        {
            SceneManager.LoadScene("Play");
        }
    }
}
